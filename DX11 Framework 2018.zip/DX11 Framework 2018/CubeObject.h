#pragma once
#include "SceneObject.h"

class CubeObject : public SceneObject
{
public:
	//CubeObject() : SceneObject() {}
	CubeObject(ApplicationGraphics* graphics) : SceneObject() {}

	//~CubeObject();

private:

};

